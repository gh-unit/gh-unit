//
//  main.m
//  Example-iOS
//
//  Created by Gabriel Handford on 1/29/14.
//  Copyright (c) 2014 Gabriel Handford. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GHUAppDelegate.h"

int main(int argc, char * argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([GHUAppDelegate class]));
  }
}
