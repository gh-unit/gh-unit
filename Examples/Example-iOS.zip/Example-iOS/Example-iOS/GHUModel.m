//
//  GHUModel.m
//  Example-iOS
//
//  Created by Gabriel Handford on 1/29/14.
//  Copyright (c) 2014 Gabriel Handford. All rights reserved.
//

#import "GHUModel.h"

@implementation GHUModel

@end
